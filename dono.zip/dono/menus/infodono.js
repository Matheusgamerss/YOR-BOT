const infodono = (prefix, numerodn, NomeDoBot, sender) => {

// NÃO APAGUE ESSE ${NickDono} nem 
//${numerodn} nem ${NomeDoBot} nem ${prefix} só se quiser apagar completo, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.

return `
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑰𝑵𝑭𝑶 𝑫𝑶𝑵𝑶 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ Solicitou: @${sender.split("@")[0]}
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩ ִPatroa: wa.me/${numerodn} 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ Patrao: wa.me/559484391098
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ╼┛`
}

exports.infodono = infodono