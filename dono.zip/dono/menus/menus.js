const menu = (prefix,NickDono, NomeDoBot, sender) => {
  
return `╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑰𝑵𝑭𝑶𝑹𝑴𝑨𝑪𝑶𝑬𝑺 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┣┬┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ Olá @${sender.split("@")[0]}
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ Prefixo:「 ${prefix} 」
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ Nome: ${NomeDoBot}
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ Dono: ${NickDono}
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ Parceria: 𝒀𝑨𝑲𝑨𝑺𝑯𝑰 𝑶𝑭𝑰𝑪𝑰𝑨𝑳
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ╼┛
​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​ 
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝐓𝐎𝐃𝐎𝐒 𝐎𝐒 𝐌𝐄𝐍𝐔𝐒 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┣┬┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Menudono
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Menuadm
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Menupremium
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Menualteradores
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Efeitosimg
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Logos
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Brincadeiras
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}Menucoins
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ╼┛
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑷𝑬𝑺𝑸𝑼𝑰𝑺𝑨/𝑫𝑶𝑾𝑵𝑳 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}play (Nome) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}playvid (Nome)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}playdoc (Nome)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}tiktok (Link) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}tiktok_audio (Link) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}instagram (Link) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}instagram2 (Link) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}insta_audio (Link) 
╰───▸
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑨𝑻𝑰𝑽𝑰𝑫𝑨𝑫𝑬𝑺 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}ping (Velocidade)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}atividade (informaçoes)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}rankativo (informaçoes)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}checkativo (@Marcar)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}ranklevel (Todos) 
╰───▸
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑭𝑰𝑮𝑼𝑹𝑰𝑵𝑯𝑨𝑺 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}attp (Texto)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}fsticker (Marcar-Foto)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}sticker (Marcar-Foto)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-random (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-raiva (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-meme (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-desenho (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-flork (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-roblox (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-anime (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-coreana (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-animais (figurinhas)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}figu-bebe (figurinhas)
╰───▸
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑪𝑴𝑫 𝑩𝑨𝑺𝑰𝑪𝑶 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}criador
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}perfil (informaçoes)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}calcular 1 + 1
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}fazernick (NICK)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}signo ( EX: virgem)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}metadinha (imagens)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}iniciar_forca
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}ppt (Pedra/Papel/Tesoura) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}jogodavelha (@Marcar) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟ ${prefix}cassino (game)
╰───▸`;
};

exports.menu = menu;

// MENU DE ADMINISTRADORES 

const adms = (prefix, sender) => { 
 
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

	return `
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑴𝑬𝑵𝑼 𝑨𝑫𝑴𝑰𝑵 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┣┬┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}ativacoes
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}so_adm
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}listanegra (NUMERO)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}tirardalista (NUMERO)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}listanegraG (NÚMERO)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}tirardalistaG (NÚMERO)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}kick [@] (pra-remover) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}ban (responder-mensagem)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}promover [@] (Ser-ADM)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rebaixar [@] (rebaixar-adm)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}totag (menciona-algo)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}grupo f/a
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}status
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}limpar (texto-invisível-gp)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}atividades (DO-GRUPO)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}linkgp
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}grupoinfo
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}hidetag (txt) (marcação)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}marcar (marca tds do gp)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}marcar2 (Marca-tds-Wa.me/)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}antipalavra 1 / 0
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}descgp (TXT)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}nomegp (Nome)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}criartabela (ESCREVA-ALGO)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}tabelagp
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ`;
};

exports.adms = adms;

// MENU DE DONO

const menudono = (prefix, sender) => {
	
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode alterar ele tod0, menos as definições, só se quiser apagar a definição completa. 	

return `
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑴𝑬𝑵𝑼 𝑫𝑶𝑵𝑶 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┣┬┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}ativacoes_dono
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}bangp
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}unbangp
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}fotomenu (MARCAR-IMG) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}blockcmd  (cmd)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}unblockcmd (cmd)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}legenda_estrangeiro (msg)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}legendabv (oq qr)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}legendasaiu (oq qr)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}legendasaiu2 (oq qr)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}legendabv2 (oq qr)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}fundobemvindo (marcar-img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}fundosaiu (marcar-img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}serpremium
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}listagp
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}antipalavrão 1 / 0
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}antiligar 1 / 0
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}addpalavra (palavrão)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}delpalavra (palavrão)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}ativo
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}ausente (fale-oq-faz)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}delpremium @(marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}addpremium @(marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}clonar [@] (rouba ft de prf)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}fotobot (img, = foto do BT)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}descriçãogp (digite-algo)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}block [@] (bloq de usar cmds) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}unblock [@] (desbloquear) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}setprefix  (prefixo-novo)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}bcgp (TM-PRA-PV-MEMBROS)
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ`;

};

exports.menudono = menudono;

// MENU DE LOGOS 

const menulogos = (prefix, sender) => {
  
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa.  
  
  return `
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑴𝑬𝑵𝑼 𝑳𝑶𝑮𝑶𝑺 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
│ Logos De 1 Texto
├─ ❑
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}logos1 (txt) 
│
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ
╭┄─▸
│ Logos De 2 Texto
├─ ❑
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}comporn (txt/txt) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}glitch (txt/txt)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}glitch3 (txt/txt)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}grafity (txt-txt)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}space (txt/txt)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}marvel (txt/txt)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}stone (txt/txt)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}steel (txt/txt)
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ`;
};

exports.menulogos = menulogos;

// MENU DE ALTERAR ÁUDIOS E VÍDEOS

const alteradores = (prefix, sender) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return`
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑴𝑬𝑵𝑼 𝑨𝑳𝑻𝑬𝑹𝑨𝑫𝑶𝑹𝑬𝑺 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
│ Alterar Videos
├─ ❑
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}videolento (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}videorapido (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}videocontrario (marca)
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ
╭┄─▸
│ Alterar Audios
├─ ❑
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}audiolento (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}audiorapido (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}grave (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}grave2 (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}esquilo (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}estourar (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}bass (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}bass2 (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}vozmenino (marca)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}audioreverse (marca)
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ`;
};

exports.alteradores = alteradores;

// MENU PREMIUM 

const menuprem = (prefix, sender) => { 

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑴𝑬𝑵𝑼 𝑷𝑹𝑬𝑴𝑰𝑼𝑴 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}ADICIONE SEUS COMANDOS PREMIUM
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ`;
};

exports.menuprem = menuprem;

// MENU DE BRINCADEIRAS.. 

const brincadeiras = (prefix, sender) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫𝑴𝑬𝑵𝑼 𝑩𝑹𝑰𝑵𝑪𝑨𝑫𝑬𝑰𝑹𝑨𝑺 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}gay (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}feio (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}corno (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}vesgo (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}bebado (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}gostoso (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}gostosa (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}beijo (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}matar (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}tapa (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}chute (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}dogolpe (marca (@))   
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}nazista (marca (@))
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}chance (fale algo) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}casal   
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rankgay     
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rankgado
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rankcorno  
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rankgostoso
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rankgostosa
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}ranknazista
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rankotakus
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}rankpau
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ
`;
};

exports.brincadeiras = brincadeiras;

// MENU DE EFEITOS DE IMAGEM, MONTAGEM Tops Kkk

const efeitos = (prefix, sender) => {

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

return `
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪      ⁞֟፝⁞〫 𝑴𝑬𝑵𝑼 𝑬𝑭𝑬𝑰𝑻𝑶𝑺 ⁞֟፝⁞〫
╰ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╯
       ▭֟፝▬
╭ㅤׄ╶╼̣̣̣̣፝֟╾╴ׅ╶╼⵿⃕╾╴ㅤ╶╼̥̥̥֟፝╾╴ׅ╶╼⵿⃕╾╴ׄㅤ╮
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}legenda (marcar)-(img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}procurado (marcar)-(img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}hitler (marcar)-(img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}preso (marcar)-(img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}lixo (marcar)-(img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}deletem (marcar)-(img)
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}morto (marcar)-(img) 
┃֪࣪├̟⊹𝄢🎴 ︪︩᪲ꯩᳩִ᳟  ${prefix}lgbt (marcar)-(img) 
┣┴┈┅ֵֹ┈┅┈┅┈┅┈┅ֵֹ┈ֻֻ໋ࣼ𔗨᮫֪݁࠭  ⊹
┣۪─ׅ݊━──̸〭ׄ╍ׅ─ׄ ׅ   ͜͡🪶 ─ׅ۬╍〭ׄ━ׄ─̸╍─ׄ`;
};

exports.efeitos = efeitos;